#!/usr/bin/env python3
"""Evaluate and apply bounded evidence-backed roadmap lifecycle effects.

Semantic review, native identity and trusted invocation belong to the caller.
This owner enforces current schemas, sources, edges and truthful effect outcomes.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import tempfile
from typing import Any

sys.dont_write_bytecode = True
_spec = importlib.util.spec_from_file_location("lifecycle_load_config", Path(__file__).with_name("load_config.py"))
if _spec is None or _spec.loader is None:
    raise RuntimeError("owner loader unavailable")
loader = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(loader)
ContractError = loader.ContractError
VERSION = "1.0"
POLICY_SHA256 = "09738d2d65ab12117308d586f77a2140a1cedebbad9d9bc33f0408fb822f1bd4"
SHA = re.compile(r"^[0-9a-f]{64}$")
ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,95}$")
STATUSES = ("planned", "specced", "in-progress", "implemented", "verified")
PHASES = {"specify": "specced", "implement": "in-progress", "closeout": "implemented"}
OWNERS = {value: key for key, value in PHASES.items()}
CHECKS = {
    "specced": {"authoring-quality", "clarification", "independent-review", "roadmap-brief", "linkage", "dependencies", "consequential-decisions"},
    "in-progress": {"current-artifacts", "dependencies", "readiness", "eligible-scope", "native-assignments"},
    "implemented": {"full-scope-completion", "attributable-delta", "convergence", "independent-code-review", "validation", "no-buildable-defects", "future-obligations-separated"},
}
ROLES = {"specced": {"FlowKit-Reviewer", "FlowKit-Roadmap Agent"},
         "in-progress": {"FlowKit-Reviewer", "FlowKit-Readiness Checker"},
         "implemented": {"FlowKit-Code Reviewer"}}
SNAPSHOT_FIELDS = {"schema_version", "feature_directory", "entry_id", "phase", "workflow_id", "workflow_version", "run_id",
                   "current_status", "source_map", "dependency_states", "scope_sha256", "pending_future_ids"}
REQUEST_FIELDS = {"schema_version", "action", "phase", "feature_directory", "entry_id", "run_id", "workflow_id",
                  "workflow_version", "mode", "decision_reference", "milestone_evidence", "snapshot"}
PROPOSAL_FIELDS = {"schema_version", "snapshot", "milestone_evidence", "decision", "from_status", "to_status",
                   "expected_roadmap_sha256", "patch_sha256", "effect_id", "recovery"}
EVIDENCE_FIELDS = {"milestone", "owning_phase", "assessments", "required_check_ids", "satisfied_check_ids",
                   "unresolved_ids", "artifact_digests", "historical_activity", "pending_future_ids"}
ASSESSMENT_FIELDS = {"schema_version", "kind", "reviewer", "state", "feature_directory", "scope_sha256",
                     "artifact_digests", "required_check_ids", "satisfied_check_ids", "unresolved_ids"}
ENTRY = re.compile(r"^###\s+(\d+)\s+[—-]\s+.+?\s+\[status:\s*([^\]]+)\]\s*$", re.M)
FIELD = re.compile(r"^-\s+\*\*([^*]+?)(?::)?\*\*:?\s*(.*)$", re.M)
EVENT = re.compile(r"<!-- flow-roadmap-lifecycle (.+?) -->")
FOOTER = re.compile(r"\*\*Version\*\*:\s*(\d+)\.(\d+)\.(\d+)\s*\|\s*\*\*Ratified\*\*:\s*(\d{4}-\d{2}-\d{2})\s*\|\s*\*\*Last Amended\*\*:\s*\d{4}-\d{2}-\d{2}")

def digest(value: Any) -> str:
    """Hash canonical structured bytes, independently of key order."""
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()

def byte_digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()

def _reject_nulls(value: Any) -> None:
    if value is None:
        raise ContractError("null-value-invalid")
    if isinstance(value, dict):
        for item in value.values():
            _reject_nulls(item)
    elif isinstance(value, list):
        for item in value:
            _reject_nulls(item)

def exact(value: Any, fields: set[str], label: str) -> dict:
    _reject_nulls(value)
    if not isinstance(value, dict) or set(value) != fields:
        raise ContractError(f"{label}-schema-invalid")
    return value

def identifier(value: Any, label: str) -> str:
    if not isinstance(value, str) or not ID.fullmatch(value) or value in {".", ".."}:
        raise ContractError(f"{label}-invalid")
    return value

def hash_value(value: Any) -> str:
    if not isinstance(value, str) or not SHA.fullmatch(value):
        raise ContractError("digest-invalid")
    return value

def strings(value: Any, label: str, *, nonempty: bool = False) -> list[str]:
    if (not isinstance(value, list) or (nonempty and not value)
            or any(not isinstance(x, str) or not x.strip() for x in value) or len(set(value)) != len(value)):
        raise ContractError(f"{label}-invalid")
    return value

def strict_json(text: str) -> Any:
    """Reject duplicate keys and nonfinite values at the wire boundary."""
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ContractError("duplicate-json-key")
            result[key] = value
        return result
    def invalid(_):
        raise ContractError("nonfinite-json-value")
    try:
        return json.loads(text, object_pairs_hook=pairs, parse_constant=invalid)
    except (ValueError, TypeError) as error:
        raise ContractError("invalid-json") from error

def relative(value: Any) -> str:
    if (not isinstance(value, str) or not value or value.startswith(("/", "~")) or "\\" in value
            or any(ord(char) < 32 for char in value) or ":" in value or any(p in {"", ".", ".."} for p in value.split("/"))):
        raise ContractError("unsafe-relative-path")
    return value

def safe_path(project: Path, value: str, *, existing: bool = True) -> Path:
    path = project / relative(value)
    cursor = project
    for part in Path(value).parts:
        cursor /= part
        if cursor.is_symlink():
            raise ContractError("symlink-path")
    loader.require_contained(path, project, "lifecycle path")
    if existing and not path.is_file():
        raise ContractError("source-file-missing")
    return path

def read_bytes(project: Path, value: str) -> bytes:
    path = safe_path(project, value)
    with path.open("rb") as stream:
        return stream.read()

def read_json(project: Path, value: str) -> Any:
    try:
        return strict_json(read_bytes(project, value).decode("utf-8"))
    except UnicodeError as error:
        raise ContractError("source-not-utf8") from error

def source_map(project: Path, values: Any) -> dict[str, str]:
    if not isinstance(values, dict) or not values:
        raise ContractError("source-map-invalid")
    return {relative(path): byte_digest(read_bytes(project, path)) for path in values}

def validate_sources(project: Path, values: Any) -> dict[str, str]:
    observed = source_map(project, values)
    if any(hash_value(value) != observed[path] for path, value in values.items()):
        raise ContractError("stale-source-evidence")
    return observed

def evidence(project: Path, references: Any) -> list[dict]:
    if not isinstance(references, list) or not references:
        raise ContractError("evidence-missing")
    seen = set()
    for ref in references:
        exact(ref, {"path", "sha256", "kind"}, "evidence")
        path = relative(ref["path"])
        if path in seen or not isinstance(ref["kind"], str) or not ref["kind"]:
            raise ContractError("evidence-invalid")
        seen.add(path)
        if byte_digest(read_bytes(project, path)) != hash_value(ref["sha256"]):
            raise ContractError("stale-assessment-evidence")
    return references

def entries(text: str) -> dict[str, dict]:
    """Read unique entry blocks, mappings and dependency declarations."""
    found = list(ENTRY.finditer(text))
    if not found:
        raise ContractError("roadmap-ledger-missing")
    result = {}
    for number, match in enumerate(found):
        entry_id = match[1]
        if entry_id in result:
            raise ContractError("duplicate-roadmap-id")
        end = found[number + 1].start() if number + 1 < len(found) else len(text)
        block = text[match.end():end]
        fields = {}
        for field in FIELD.finditer(block):
            key = field[1].rstrip(":").lower()
            # Fields after the next top-level section are not entry fields.
            if re.search(r"^## ", block[:field.start()], re.M):
                break
            if key in fields:
                raise ContractError("duplicate-roadmap-field")
            fields[key] = field[2].strip()
        mapping = fields.get("spec dir")
        if mapping is not None:
            mapping = mapping.strip().strip("`").rstrip("/")
            relative(mapping)
        declaration = fields.get("depends on", "").strip()
        clauses = [clause.strip() for clause in declaration.split(";")]
        clauses = [clause[:-1].rstrip() if clause.endswith(".") else clause for clause in clauses]
        positive = clauses[0]
        id_token = r"(?:\d{3}|`\d{3}`)(?:-brief)?"
        positive_list = (rf"{id_token}(?:\s+\([^()\d;]+\))?"
                         rf"(?:\s*,\s*{id_token}(?:\s+\([^()\d;]+\))?)*")
        negative_list = rf"no dependency on {id_token}(?:\s*,\s*{id_token})*"
        retired = re.fullmatch(r"~~(.*?)~~ _None — dependency edge retired with", positive)
        if positive.lower() in {"", "none"}:
            if len(clauses) > 1:
                raise ContractError("dependency-annotation-invalid")
            dependencies = []
        elif retired and re.fullmatch(positive_list, retired[1].rstrip(".").strip()):
            if len(clauses) > 1:
                raise ContractError("dependency-annotation-invalid")
            dependencies = []
        elif re.fullmatch(positive_list, positive):
            dependencies = re.findall(r"\d{3}", positive)
        else:
            raise ContractError("dependency-declaration-invalid")
        negatives = []
        for annotation in clauses[1:]:
            if not re.fullmatch(negative_list, annotation, re.I):
                raise ContractError("dependency-annotation-invalid")
            negatives.extend(re.findall(r"\d{3}", annotation))
        if len(set(negatives)) != len(negatives):
            raise ContractError("duplicate-dependency-annotation")
        if set(negatives) & set(dependencies):
            raise ContractError("dependency-declaration-contradicts")
        if len(set(dependencies)) != len(dependencies):
            raise ContractError("duplicate-dependency")
        result[entry_id] = {"id": entry_id, "status": match[2], "spec_dir": mapping,
                            "dependencies": dependencies, "start": match.start(), "heading_end": match.end(), "end": end}
    return result

def dependency_states(ledger: dict, selected: str) -> list[dict]:
    visiting, visited = set(), set()
    def walk(entry_id):
        if entry_id in visiting:
            raise ContractError("dependency-cycle")
        if entry_id in visited:
            return
        visiting.add(entry_id)
        for dep in ledger[entry_id]["dependencies"]:
            if dep not in ledger:
                raise ContractError("dependency-missing")
            walk(dep)
        visiting.remove(entry_id)
        visited.add(entry_id)
    walk(selected)
    return [{"entry_id": dep, "status": ledger[dep]["status"]} for dep in sorted(visited - {selected})]

def payload_prefix(project: Path) -> str:
    # The owner source checkout can also contain an older dogfood installation.
    source_script = project / "scripts/python/phase_lifecycle.py"
    if ((project / "extension.yml").is_file() and source_script.is_file()
            and source_script.read_bytes() == Path(__file__).read_bytes()):
        return ""
    installed = ".specify/extensions/flow-roadmap/"
    if (project / installed / "extension.yml").exists():
        return installed
    if (project / "extension.yml").exists():
        return ""
    raise ContractError("lifecycle-owner-contract-unavailable")

def pending_ids(project: Path, feature: str) -> list[str]:
    path = f"{feature}/validation/future-obligations.json"
    if not (project / path).exists():
        return []
    record = read_json(project, path)
    if (not isinstance(record, dict) or record.get("schema_version") != VERSION
            or record.get("feature_directory") != feature or not isinstance(record.get("obligations"), list)):
        raise ContractError("future-obligations-invalid")
    result = []
    for item in record["obligations"]:
        if not isinstance(item, dict) or item.get("status") != "pending":
            raise ContractError("future-obligations-invalid")
        result.append(identifier(item.get("id"), "future-obligation"))
    strings(result, "future-obligations")
    return sorted(result)

def collect_snapshot(project: Path, request: dict, yaml: Any) -> dict:
    """Collect current bytes rather than accepting the supplied snapshot as fact."""
    supplied = exact(request["snapshot"], SNAPSHOT_FIELDS, "snapshot")
    feature = relative(request["feature_directory"])
    if not feature.startswith("specs/"):
        raise ContractError("feature-directory-invalid")
    prefix = payload_prefix(project)
    payload = project / prefix
    config = loader.resolve_configuration(project, payload, yaml)
    roadmap = relative(config["roadmap_path"])
    raw = read_bytes(project, roadmap)
    ledger = entries(raw.decode("utf-8"))
    selected = request["entry_id"]
    if selected not in ledger:
        raise ContractError("roadmap-entry-missing")
    selected_path = safe_path(project, feature + "/spec.md")
    selected_stat = selected_path.stat()
    mapped = []
    for item in ledger.values():
        if item["spec_dir"] is None:
            continue
        candidate_path = safe_path(project, item["spec_dir"] + "/spec.md", existing=False)
        if candidate_path.exists():
            observed = candidate_path.stat()
            if (observed.st_dev, observed.st_ino) == (selected_stat.st_dev, selected_stat.st_ino):
                mapped.append(item)
    if len(mapped) != 1 or mapped[0]["id"] != selected:
        raise ContractError("roadmap-mapping-not-unique")
    pointer = read_json(project, ".specify/feature.json")
    if not isinstance(pointer, dict) or pointer.get("feature_directory") != feature:
        raise ContractError("active-feature-mismatch")
    manifest = loader._load_yaml(read_bytes(project, prefix + "extension.yml").decode(), "owner manifest", yaml)
    if manifest.get("extension", {}).get("id") != "flow-roadmap":
        raise ContractError("owner-identity-invalid")
    version = manifest.get("extension", {}).get("version", "")
    if not re.fullmatch(r"\d+\.\d+\.\d+", version) or tuple(map(int, version.split("."))) < (0, 3, 0):
        raise ContractError("lifecycle-owner-contract-unavailable")
    declared = [item.get("file") for item in manifest.get("provides", {}).get("scripts", [])]
    if "scripts/python/phase_lifecycle.py" not in declared:
        raise ContractError("lifecycle-owner-contract-unavailable")
    required = {roadmap, ".specify/feature.json", ".specify/memory/constitution.md",
                f"{feature}/spec.md", request["decision_reference"], prefix + "extension.yml",
                prefix + "scripts/python/load_config.py", prefix + "scripts/python/review_contract.py",
                prefix + "scripts/python/phase_lifecycle.py"}
    for group in request["milestone_evidence"]:
        refs = group["assessments"]
        history = group["historical_activity"]
        evidence(project, refs)
        if history:
            evidence(project, history)
        required.update(validate_sources(project, group["artifact_digests"]))
        for ref in refs:
            record = exact(read_json(project, ref["path"]), ASSESSMENT_FIELDS, "assessment")
            required.update(validate_sources(project, record["artifact_digests"]))
        for ref in refs + history:
            required.add(relative(ref["path"]))
    if request["phase"] != "specify" or ledger[selected]["status"] in {"in-progress", "implemented", "verified"}:
        required |= {f"{feature}/plan.md", f"{feature}/tasks.md"}
    quality = f"{feature}/checklists/requirements.md"
    if (project / quality).exists():
        required.add(quality)
    for path in (".specify/extensions/flow-roadmap/roadmap-config.yml", f"{feature}/validation/future-obligations.json"):
        if (project / path).exists():
            required.add(path)
    graph = f".specify/workflows/{request['workflow_id']}/workflow.yml"
    manual = f"{feature}/validation/manual-route.json"
    if (project / graph).exists():
        required |= {graph, ".specify/flow-kit/manifest.yml", ".specify/flow-kit/skills-install.json", ".specify/bundle-records.json"}
        definition = loader._load_yaml(read_bytes(project, graph).decode(), "workflow", yaml)
        graph_version = definition.get("workflow", {}).get("version")
        if graph_version != request["workflow_version"]:
            raise ContractError("workflow-version-mismatch")
        minimum = {"specify": (0, 3, 0), "implement": (0, 7, 0), "closeout": (0, 8, 0)}[request["phase"]]
        if not isinstance(graph_version, str) or not re.fullmatch(r"\d+\.\d+\.\d+", graph_version) or tuple(map(int, graph_version.split("."))) < minimum:
            raise ContractError("lifecycle-workflow-contract-unavailable")
        controllers = loader._load_yaml(read_bytes(project, ".specify/flow-kit/manifest.yml").decode(), "controller manifest", yaml)
        controller_version = controllers.get("package", {}).get("version", "")
        if not isinstance(controller_version, str) or not re.fullmatch(r"\d+\.\d+\.\d+", controller_version) or tuple(map(int, controller_version.split("."))) < (0, 8, 0):
            raise ContractError("lifecycle-controller-contract-unavailable")
        def has_owner_route(nodes):
            for node in nodes if isinstance(nodes, list) else []:
                if not isinstance(node, dict):
                    continue
                metadata = node.get("flow_kit", {})
                if (node.get("type") == "command" and node.get("command") == "speckit.flow-roadmap.write"
                        and metadata.get("delegated") is True and metadata.get("agent") == "FlowKit-Roadmap Agent"
                        and "PHASE_MILESTONE_REQUEST=" in node.get("input", {}).get("args", "")):
                    return True
                branches = [node.get("steps", []), node.get("default", []), *node.get("cases", {}).values()]
                if any(has_owner_route(branch) for branch in branches):
                    return True
            return False
        if not has_owner_route(definition.get("steps", [])):
            raise ContractError("lifecycle-owner-route-unavailable")
    elif (project / manual).exists():
        route = read_json(project, manual)
        exact(route, {"schema_version", "phase", "workflow_id", "workflow_version", "run_id",
                      "feature_directory", "commands", "native_assignments", "source_evidence"}, "manual-route")
        if any(route[field] != request[field] for field in ("phase", "workflow_id", "workflow_version", "run_id", "feature_directory")) or route["schema_version"] != VERSION:
            raise ContractError("manual-route-mismatch")
        strings(route["commands"], "manual-commands", nonempty=True)
        strings(route["native_assignments"], "manual-assignments", nonempty=True)
        evidence(project, route["source_evidence"])
        required.add(manual)
    else:
        raise ContractError("lifecycle-owner-contract-unavailable")
    if not isinstance(supplied["source_map"], dict) or not required.issubset(supplied["source_map"]):
        raise ContractError("required-source-coverage-missing")
    actual_map = {relative(path): byte_digest(read_bytes(project, path)) for path in set(supplied["source_map"]) | required}
    return {"schema_version": VERSION, "feature_directory": feature, "entry_id": selected,
            "phase": request["phase"], "workflow_id": request["workflow_id"], "workflow_version": request["workflow_version"],
            "run_id": request["run_id"], "current_status": ledger[selected]["status"], "source_map": actual_map,
            "dependency_states": dependency_states(ledger, selected), "scope_sha256": byte_digest(read_bytes(project, f"{feature}/spec.md")),
            "pending_future_ids": pending_ids(project, feature)}

def validate_assessment(project: Path, ref: dict, snapshot: dict, allowed_roles: set[str]) -> dict:
    record = exact(read_json(project, ref["path"]), ASSESSMENT_FIELDS, "assessment")
    if (record["schema_version"] != VERSION or record["kind"] != ref["kind"]
            or record["reviewer"] not in allowed_roles or record["state"] not in {"ready", "complete"}
            or record["feature_directory"] != snapshot["feature_directory"] or record["scope_sha256"] != snapshot["scope_sha256"]):
        raise ContractError("independent-assessment-invalid")
    required = strings(record["required_check_ids"], "assessment-checks", nonempty=True)
    satisfied = strings(record["satisfied_check_ids"], "assessment-checks", nonempty=True)
    if set(required) != set(satisfied) or strings(record["unresolved_ids"], "assessment-unresolved"):
        raise ContractError("independent-assessment-incomplete")
    artifacts = validate_sources(project, record["artifact_digests"])
    if artifacts.get(f"{snapshot['feature_directory']}/spec.md") != snapshot["scope_sha256"]:
        raise ContractError("assessment-scope-input-missing")
    return record

def validate_milestone(project: Path, groups: list, target: str, snapshot: dict, *, recovery: bool) -> dict:
    selected = [group for group in groups if group.get("milestone") == target]
    if len(selected) != 1:
        raise ContractError("milestone-proof-missing")
    group = exact(selected[0], EVIDENCE_FIELDS, "milestone-evidence")
    if group["owning_phase"] != OWNERS[target]:
        raise ContractError("milestone-owner-mismatch")
    required = strings(group["required_check_ids"], "milestone-checks", nonempty=True)
    satisfied = strings(group["satisfied_check_ids"], "milestone-checks", nonempty=True)
    if set(required) != CHECKS[target] or set(satisfied) != CHECKS[target] or strings(group["unresolved_ids"], "milestone-unresolved"):
        raise ContractError("milestone-proof-incomplete")
    artifacts = validate_sources(project, group["artifact_digests"])
    feature = snapshot["feature_directory"]
    must = {f"{feature}/spec.md"}
    if target != "specced":
        must |= {f"{feature}/plan.md", f"{feature}/tasks.md"}
    if not must.issubset(artifacts) or artifacts[f"{feature}/spec.md"] != snapshot["scope_sha256"]:
        raise ContractError("milestone-current-artifacts-missing")
    refs = evidence(project, group["assessments"])
    seen_roles, checks = set(), set()
    independent_inputs = {}
    for ref in refs:
        record = validate_assessment(project, ref, snapshot, ROLES[target])
        seen_roles.add(record["reviewer"])
        independent_inputs.setdefault(record["reviewer"], set()).update(record["artifact_digests"])
        checks.update(record["satisfied_check_ids"])
    if not ROLES[target].issubset(seen_roles) or not CHECKS[target].issubset(checks):
        raise ContractError("milestone-independent-coverage-incomplete")
    scope_reviewer = "FlowKit-Code Reviewer" if target == "implemented" else "FlowKit-Reviewer"
    if not must.issubset(independent_inputs.get(scope_reviewer, set())):
        raise ContractError("independent-reviewed-input-coverage-missing")

    if sorted(strings(group["pending_future_ids"], "pending-future-ids")) != snapshot["pending_future_ids"]:
        raise ContractError("future-obligations-mismatch")
    history = group["historical_activity"]
    if not isinstance(history, list):
        raise ContractError("historical-activity-invalid")
    if recovery and target == "in-progress":
        evidence(project, history)
        for ref in history:
            record = read_json(project, ref["path"])
            if (not isinstance(record, dict) or record.get("kind") != "authorized-implementation-start"
                    or record.get("scope_sha256") != snapshot["scope_sha256"]):
                raise ContractError("historical-start-unsubstantiated")
            occurrence(record.get("occurred_at"))
    elif history:
        evidence(project, history)
    return group

def validate_request(request: dict) -> None:
    action = request.get("action") if isinstance(request, dict) else None
    exact(request, REQUEST_FIELDS | ({"proposal"} if action == "revalidate" else set()), "request")
    if request["schema_version"] != VERSION or action not in {"prepare", "revalidate"}:
        raise ContractError("request-version-or-action-invalid")
    if request["phase"] not in PHASES or request["mode"] not in {"normal", "recovery"}:
        raise ContractError("phase-or-mode-invalid")
    for key in ("entry_id", "run_id", "workflow_id", "workflow_version"):
        identifier(request[key], key)
    relative(request["feature_directory"])
    relative(request["decision_reference"])
    if not isinstance(request["milestone_evidence"], list):
        raise ContractError("milestone-evidence-invalid")
    for group in request["milestone_evidence"]:
        exact(group, EVIDENCE_FIELDS, "milestone-evidence")
        if group["milestone"] not in CHECKS:
            raise ContractError("milestone-invalid")
    if len({g["milestone"] for g in request["milestone_evidence"]}) != len(request["milestone_evidence"]):
        raise ContractError("duplicate-milestone-evidence")

def blocked(reason: str, snapshot: dict | None = None) -> dict:
    if not re.fullmatch(r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*", reason):
        reason = "lifecycle-source-validation-failed"
    result = {"state": "blocked", "reason_code": reason, "evidence": [], "blocking_ids": [reason],
              "resume_action": "supply-current-lifecycle-evidence"}
    if snapshot is not None:
        result["snapshot"] = snapshot
    return result

def _operations(proposal: dict) -> dict:
    operations = {key: value for key, value in proposal.items() if key != "patch_sha256"}
    operations["recovery"] = {key: value for key, value in proposal["recovery"].items() if key != "verification"}
    return operations

def evaluate(project: Path, request: dict, yaml: Any) -> dict:
    """Prepare exactly one edge or a truthful event-free assessment."""
    validate_request(request)
    try:
        snapshot = collect_snapshot(project, request, yaml)
        if snapshot != request["snapshot"]:
            raise ContractError("stale-source-snapshot")
        if any(dep["status"] != "verified" for dep in snapshot["dependency_states"]):
            raise ContractError("dependencies-not-verified")
        decision = read_json(project, request["decision_reference"])
        exact(decision, {"schema_version", "policy_sha256", "feature_directory", "phase", "scope_sha256", "kind", "reference"}, "decision")
        if (decision["schema_version"] != VERSION or decision["policy_sha256"] != POLICY_SHA256
                or any(decision[field] != snapshot[field] for field in ("feature_directory", "phase", "scope_sha256"))
                or decision["kind"] not in {"routine-invocation", "operator-resolution"}
                or not isinstance(decision["reference"], str) or not decision["reference"]):
            raise ContractError("governing-contract-mismatch")
        current = snapshot["current_status"]
        ceiling = PHASES[request["phase"]]
        if current not in STATUSES:
            return {"state": "question", "reason_code": "lifecycle-state-conflict", "snapshot": snapshot,
                    "evidence": [], "blocking_ids": ["lifecycle-state-conflict"],
                    "request": {"kind": "question", "step_id": "resolve-phase-lifecycle-conflict",
                    "question": "Resolve the current lifecycle state before an adjacent milestone effect.",
                    "options": ["Keep state and stop", "Provide an explicit reconciliation instruction"], "allow_custom_answer": True}}
        ci, ti = STATUSES.index(current), STATUSES.index(ceiling)
        if ci >= ti:
            target = current if current != "verified" else "implemented"
            group = validate_milestone(project, request["milestone_evidence"], ceiling, snapshot, recovery=False)
            if target != ceiling:
                validate_milestone(project, request["milestone_evidence"], target, snapshot, recovery=False)
            return {"state": "no-op", "reason_code": "consistent-milestone-retained", "snapshot": snapshot,
                    "evidence": group["assessments"], "blocking_ids": [], "retained_status": current}
        target = STATUSES[ci + 1]
        if request["mode"] == "normal" and target != ceiling:
            raise ContractError("adjacent-phase-recovery-required")
        group = validate_milestone(project, request["milestone_evidence"], target, snapshot,
                                   recovery=request["mode"] == "recovery" and request["phase"] != OWNERS[target])
        prefix = payload_prefix(project)
        config = loader.resolve_configuration(project, project / prefix, yaml)
        raw = read_bytes(project, config["roadmap_path"])
        proposal = {"schema_version": VERSION, "snapshot": snapshot, "milestone_evidence": request["milestone_evidence"],
                    "decision": {"reference": request["decision_reference"],
                                 "sha256": byte_digest(read_bytes(project, request["decision_reference"])),
                                 "contract_sha256": POLICY_SHA256},
                    "from_status": current, "to_status": target, "expected_roadmap_sha256": byte_digest(raw),
                    "effect_id": "lifecycle-" + digest({"snapshot": snapshot, "to_status": target})[:32],
                    "recovery": {"mode": request["mode"], "ceiling": ceiling, "roadmap_path": config["roadmap_path"],
                                 "source_preimage": raw.decode("utf-8"), "verification": []}}
        proposal["patch_sha256"] = digest(_operations(proposal))
        if request["action"] == "revalidate" and proposal != request["proposal"]:
            raise ContractError("prepared-proposal-changed")
        return {"state": "ready", "reason_code": "adjacent-milestone-substantiated", "snapshot": snapshot,
                "evidence": group["assessments"], "blocking_ids": [], "proposal": proposal}
    except ContractError as error:
        return blocked(str(error), locals().get("snapshot"))

def occurrence(value: Any) -> str:
    if not isinstance(value, str) or "T" not in value:
        raise ContractError("occurrence-time-invalid")
    try:
        observed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as error:
        raise ContractError("occurrence-time-invalid") from error
    if observed.tzinfo is None or observed.utcoffset() is None:
        raise ContractError("occurrence-time-invalid")
    return value

def candidate(proposal: dict, occurred_at: str) -> tuple[bytes, dict]:
    """Apply only approved operations, supplying writer-observed operation time."""
    occurrence(occurred_at)
    text = proposal["recovery"]["source_preimage"]
    if byte_digest(text.encode()) != proposal["expected_roadmap_sha256"]:
        raise ContractError("proposal-preimage-invalid")
    ledger = entries(text)
    item = ledger.get(proposal["snapshot"]["entry_id"])
    if item is None or item["status"] != proposal["from_status"]:
        raise ContractError("proposal-entry-preimage-invalid")
    current = proposal["from_status"]
    target = proposal["to_status"]
    if current not in STATUSES or target not in OWNERS or STATUSES.index(target) != STATUSES.index(current) + 1:
        raise ContractError("proposal-edge-invalid")
    heading = text[item["start"]:item["heading_end"]]
    updated_heading = heading.replace(f"[status: {current}]", f"[status: {target}]", 1)
    if updated_heading == heading:
        raise ContractError("roadmap-heading-format-unsupported")
    snapshot = proposal["snapshot"]
    event = {"effect_id": proposal["effect_id"], "owning_phase": OWNERS[target], "executing_phase": snapshot["phase"],
             "workflow_id": snapshot["workflow_id"], "workflow_version": snapshot["workflow_version"], "run_id": snapshot["run_id"],
             "entry_id": snapshot["entry_id"], "feature_directory": snapshot["feature_directory"],
             "scope_sha256": snapshot["scope_sha256"], "from_status": current, "to_status": target,
             "occurred_at": occurred_at, "roadmap_before_sha256": proposal["expected_roadmap_sha256"],
             "patch_sha256": proposal["patch_sha256"]}
    encoded_event = json.dumps(event, sort_keys=True, separators=(",", ":")).replace("<", "\\u003c").replace(">", "\\u003e")
    rendered = "<!-- flow-roadmap-lifecycle " + encoded_event + " -->"
    # Insert directly after the selected heading; all unrelated prose remains byte-identical.
    text = text[:item["start"]] + updated_heading + "\n\n" + rendered + text[item["heading_end"]:]
    footers = list(FOOTER.finditer(text))
    if len(footers) != 1:
        raise ContractError("roadmap-version-footer-invalid")
    footer = footers[0]
    old_version = ".".join(footer.group(i) for i in (1, 2, 3))
    new_version = f"{footer[1]}.{footer[2]}.{int(footer[3])+1}"
    date = occurred_at[:10]
    replacement = f"**Version**: {new_version} | **Ratified**: {footer[4]} | **Last Amended**: {date}"
    text = text[:footer.start()] + replacement + text[footer.end():]
    impact = (f"<!--\nSYNC IMPACT REPORT\n==================\nVersion change: {old_version} → {new_version}\n"
              f"Bump rationale: PATCH — evidence-backed adjacent lifecycle status/provenance for entry {snapshot['entry_id']}.\n"
              f"Effect: {proposal['effect_id']}; owner {OWNERS[target]}; actual occurrence {occurred_at}.\n"
              "Unrelated entries, decisions and history preserved. No verified, acceptance, integration or publication effect.\n-->\n\n")
    return (impact + text).encode("utf-8"), event

def validate_proposal(proposal: dict) -> None:
    exact(proposal, PROPOSAL_FIELDS, "proposal")
    exact(proposal["snapshot"], SNAPSHOT_FIELDS, "snapshot")
    exact(proposal["decision"], {"reference", "sha256", "contract_sha256"}, "proposal-decision")
    exact(proposal["recovery"], {"mode", "ceiling", "roadmap_path", "source_preimage", "verification"}, "recovery")
    if proposal["schema_version"] != VERSION or proposal["decision"]["contract_sha256"] != POLICY_SHA256:
        raise ContractError("proposal-version-or-policy-invalid")
    for value in (proposal["patch_sha256"], proposal["expected_roadmap_sha256"], proposal["decision"]["sha256"]):
        hash_value(value)
    identifier(proposal["effect_id"], "effect-id")
    if proposal["patch_sha256"] != digest(_operations(proposal)):
        raise ContractError("proposal-patch-digest-invalid")
    if not isinstance(proposal["recovery"]["source_preimage"], str):
        raise ContractError("proposal-preimage-invalid")
    if proposal["recovery"]["mode"] not in {"normal", "recovery"} or proposal["recovery"]["ceiling"] != PHASES.get(proposal["snapshot"]["phase"]):
        raise ContractError("recovery-ceiling-invalid")
    relative(proposal["recovery"]["roadmap_path"])
    for group in proposal["milestone_evidence"]:
        exact(group, EVIDENCE_FIELDS, "milestone-evidence")
        for path, expected in group["artifact_digests"].items():
            relative(path)
            if proposal["snapshot"]["source_map"].get(path) != hash_value(expected):
                raise ContractError("original-input-snapshot-binding-missing")
        for ref in group["assessments"] + group["historical_activity"]:
            exact(ref, {"path", "sha256", "kind"}, "evidence")
            path = relative(ref["path"])
            if proposal["snapshot"]["source_map"].get(path) != hash_value(ref["sha256"]):
                raise ContractError("original-evidence-snapshot-binding-missing")
    candidate(proposal, "2000-01-01T00:00:00Z")  # structural preview only; never used as effect time

def request_from_proposal(proposal: dict) -> dict:
    snapshot = proposal["snapshot"]
    return {"schema_version": VERSION, "action": "prepare",
            **{key: snapshot[key] for key in ("phase", "feature_directory", "entry_id", "run_id", "workflow_id", "workflow_version")},
            "mode": proposal["recovery"]["mode"], "decision_reference": proposal["decision"]["reference"],
            "milestone_evidence": proposal["milestone_evidence"], "snapshot": snapshot}

def receipt_base(proposal: dict, refs: list) -> dict:
    snapshot = proposal["snapshot"]
    return {"schema_version": VERSION, "feature_directory": snapshot["feature_directory"], "entry_id": snapshot["entry_id"],
            "phase": snapshot["phase"], "scope_sha256": snapshot["scope_sha256"], "evidence": refs,
            "record_state": "recorded"}

def validate_receipt(receipt: dict) -> dict:
    """Enforce the approved discriminated effect/record envelope."""
    base = {"schema_version", "feature_directory", "entry_id", "phase", "scope_sha256", "evidence", "effect_state", "record_state"}
    state = receipt.get("effect_state") if isinstance(receipt, dict) else None
    extras = {
        "applied": {"effect_id", "owning_phase", "from_status", "to_status", "occurred_at", "roadmap_before_sha256", "roadmap_after_sha256"},
        "no-op": {"assessment_id", "retained_status", "roadmap_before_sha256", "roadmap_after_sha256"},
        "not-applied": {"proposed_effect_id", "owning_phase", "proposed_from_status", "proposed_to_status", "reason_code", "roadmap_before_sha256"},
        "indeterminate": {"proposed_effect_id", "owning_phase", "proposed_from_status", "proposed_to_status", "reason_code", "roadmap_before_sha256"},
    }
    if state not in extras:
        raise ContractError("receipt-effect-state-invalid")
    allowed = base | extras[state]
    optional = {"not-applied": {"roadmap_after_sha256"}, "indeterminate": {"observed_roadmap_sha256"}}.get(state, set())
    record_state = receipt.get("record_state")
    if record_state == "failed":
        allowed |= {"record_error"}
    elif record_state == "recovered" and state == "applied":
        allowed |= {"recovery_evidence"}
    elif record_state != "recorded":
        raise ContractError("receipt-record-state-invalid")
    if not isinstance(receipt, dict) or not allowed.issubset(receipt) or set(receipt) - allowed - optional:
        raise ContractError("receipt-schema-invalid")
    if any(value is None for value in receipt.values()) or receipt["schema_version"] != VERSION or receipt["phase"] not in PHASES:
        raise ContractError("receipt-value-invalid")
    relative(receipt["feature_directory"])
    identifier(receipt["entry_id"], "receipt-entry")
    hash_value(receipt["scope_sha256"])
    for field, value in receipt.items():
        if field.endswith("sha256"):
            hash_value(value)
    _reject_nulls(receipt)
    for field in ("evidence", "recovery_evidence"):
        if field not in receipt:
            continue
        refs = receipt[field]
        if not isinstance(refs, list) or not refs:
            raise ContractError("receipt-evidence-missing")
        for ref in refs:
            exact(ref, {"path", "sha256", "kind"}, "receipt-evidence")
            relative(ref["path"])
            hash_value(ref["sha256"])
            if not isinstance(ref["kind"], str) or not ref["kind"]:
                raise ContractError("receipt-evidence-invalid")
    if state == "applied":
        occurrence(receipt["occurred_at"])
        identifier(receipt["effect_id"], "receipt-effect")
        if receipt["to_status"] not in OWNERS or receipt["owning_phase"] != OWNERS[receipt["to_status"]]:
            raise ContractError("receipt-edge-invalid")
        if receipt["from_status"] not in STATUSES or STATUSES.index(receipt["to_status"]) != STATUSES.index(receipt["from_status"]) + 1:
            raise ContractError("receipt-edge-invalid")
    elif state == "no-op":
        identifier(receipt["assessment_id"], "receipt-assessment")
        if receipt["retained_status"] not in STATUSES or receipt["roadmap_before_sha256"] != receipt["roadmap_after_sha256"]:
            raise ContractError("receipt-no-op-invalid")
    else:
        identifier(receipt["proposed_effect_id"], "receipt-proposed-effect")
        if receipt["proposed_to_status"] not in OWNERS or receipt["owning_phase"] != OWNERS[receipt["proposed_to_status"]]:
            raise ContractError("receipt-proposed-edge-invalid")
        if receipt["proposed_from_status"] not in STATUSES or STATUSES.index(receipt["proposed_to_status"]) != STATUSES.index(receipt["proposed_from_status"]) + 1:
            raise ContractError("receipt-proposed-edge-invalid")
        if not isinstance(receipt["reason_code"], str) or not receipt["reason_code"]:
            raise ContractError("receipt-reason-invalid")
    if record_state == "failed" and (not isinstance(receipt["record_error"], str) or not receipt["record_error"]):
        raise ContractError("receipt-record-error-invalid")
    if record_state == "recovered" and (not isinstance(receipt["recovery_evidence"], list) or not receipt["recovery_evidence"]):
        raise ContractError("receipt-recovery-evidence-invalid")
    return receipt

class PostEffectError(ContractError):
    """An established effect followed by a blocked current source guard."""
    def __init__(self, receipt: dict):
        super().__init__("effect-applied-source-evidence-changed")
        self.receipt = receipt

def _atomic(path: Path, raw: bytes, expected_sha256: str | None = None) -> None:
    descriptor, temporary = tempfile.mkstemp(prefix=".lifecycle-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        if expected_sha256 is not None and byte_digest(path.read_bytes()) != expected_sha256:
            raise ContractError("roadmap-preimage-changed")
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)

def persist_receipt(project: Path, receipt: dict, run_id: str) -> dict:
    """Report actual receipt persistence separately from the roadmap effect."""
    validate_receipt(receipt)
    try:
        key = receipt.get("effect_id", receipt.get("assessment_id", receipt.get("proposed_effect_id")))
        relative_path = f".specify/flow-controllers/runs/{identifier(run_id, 'run-id')}/lifecycle-receipts/{identifier(key, 'receipt-id')}.json"
        raw = (json.dumps(receipt, sort_keys=True, indent=2) + "\n").encode()
        base_path = safe_path(project, relative_path, existing=False)
        base_path.parent.mkdir(parents=True, exist_ok=True)
        reserved = False
        for index in range(100):
            selected = relative_path if index == 0 else relative_path[:-5] + f"-{index}.json"
            path = safe_path(project, selected, existing=False)
            if path.exists():
                if read_bytes(project, selected) == raw:
                    return receipt
                continue
            try:
                descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
            except FileExistsError:
                continue
            os.close(descriptor)
            reserved = True
            break
        if not reserved:
            raise ContractError("receipt-collision-limit")
        safe_path(project, selected)
        _atomic(path, raw, expected_sha256=byte_digest(b""))
        if strict_json(read_bytes(project, selected).decode()) != receipt:
            raise ContractError("receipt-readback-mismatch")
    except (OSError, ContractError):
        receipt = {key: value for key, value in receipt.items() if key != "recovery_evidence"}
        receipt.update(record_state="failed", record_error="receipt-persistence-failed")
        validate_receipt(receipt)
    return receipt

def apply(project: Path, proposal: dict, yaml: Any) -> dict:
    """Revalidate and perform one guarded owner effect with truthful readback."""
    validate_proposal(proposal)
    request = request_from_proposal(proposal)
    refs = next(group["assessments"] for group in proposal["milestone_evidence"] if group["milestone"] == proposal["to_status"])
    base = receipt_base(proposal, refs)
    path = safe_path(project, proposal["recovery"]["roadmap_path"])
    lock = safe_path(project, ".specify/flow-roadmap/lifecycle.lock", existing=False)
    lock.parent.mkdir(parents=True, exist_ok=True)
    if lock.exists() and not lock.is_file():
        raise ContractError("lifecycle-lock-not-regular")
    flags = os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(lock, flags, 0o600)
    try:
        with os.fdopen(descriptor, "a+b") as stream:
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
            observed_before = read_bytes(project, proposal["recovery"]["roadmap_path"])
            prior = [strict_json(match[1]) for match in EVENT.finditer(observed_before.decode("utf-8")) if strict_json(match[1]).get("effect_id") == proposal["effect_id"]]
            if prior:
                if len(prior) != 1:
                    raise ContractError("duplicate-existing-effect")
                raw, event = candidate(proposal, prior[0].get("occurred_at"))
                if raw != observed_before or event != prior[0]:
                    raise ContractError("existing-effect-unestablished")
                for source, expected in proposal["snapshot"]["source_map"].items():
                    if source != proposal["recovery"]["roadmap_path"] and byte_digest(read_bytes(project, source)) != hash_value(expected):
                        raise ContractError("stale-recovery-source")
                recovery = evidence(project, proposal["recovery"]["verification"])
                current = dict(proposal["snapshot"])
                current["scope_sha256"] = byte_digest(read_bytes(project, f"{current['feature_directory']}/spec.md"))
                for ref in recovery:
                    verified = validate_assessment(project, ref, current, {"FlowKit-Reviewer"})
                    if ref["kind"] != "effect-recovery" or set(verified["required_check_ids"]) != {"existing-event", "current-readback", "current-scope", "independent-review"}:
                        raise ContractError("recovery-verification-incomplete")
                    if verified["artifact_digests"].get(proposal["recovery"]["roadmap_path"]) != byte_digest(observed_before):
                        raise ContractError("recovery-readback-proof-missing")
                receipt = {**base, "effect_state": "applied", "record_state": "recovered", "recovery_evidence": recovery,
                           **{key: event[key] for key in ("effect_id", "owning_phase", "from_status", "to_status", "occurred_at")},
                           "roadmap_before_sha256": proposal["expected_roadmap_sha256"], "roadmap_after_sha256": byte_digest(observed_before)}
                return persist_receipt(project, receipt, proposal["snapshot"]["run_id"])
            verdict = evaluate(project, request, yaml)
            stable = dict(proposal)
            stable["recovery"] = {**proposal["recovery"], "verification": []}
            stable["patch_sha256"] = digest(_operations(stable))
            if verdict["state"] != "ready" or verdict["proposal"] != stable:
                receipt = {**base, "effect_state": "not-applied", "proposed_effect_id": proposal["effect_id"],
                           "owning_phase": OWNERS[proposal["to_status"]], "proposed_from_status": proposal["from_status"],
                           "proposed_to_status": proposal["to_status"], "reason_code": verdict.get("reason_code", "prepared-proposal-changed"),
                           "roadmap_before_sha256": proposal["expected_roadmap_sha256"], "roadmap_after_sha256": byte_digest(observed_before)}
                return persist_receipt(project, receipt, proposal["snapshot"]["run_id"])
            occurred_at = datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")
            raw, event = candidate(proposal, occurred_at)
            definitely_rejected = False
            try:
                safe_path(project, proposal["recovery"]["roadmap_path"])
                _atomic(path, raw, expected_sha256=proposal["expected_roadmap_sha256"])
            except (OSError, ContractError) as error:
                definitely_rejected = isinstance(error, ContractError) and str(error) == "roadmap-preimage-changed"
                pass  # An error exit alone establishes neither application nor nonapplication.
            try:
                after = read_bytes(project, proposal["recovery"]["roadmap_path"])
            except (OSError, ContractError):
                after = None
            if after == raw:
                receipt = {**base, "effect_state": "applied",
                           **{key: event[key] for key in ("effect_id", "owning_phase", "from_status", "to_status", "occurred_at")},
                           "roadmap_before_sha256": byte_digest(observed_before), "roadmap_after_sha256": byte_digest(after)}
            else:
                state = "not-applied" if definitely_rejected or after == observed_before else "indeterminate"
                receipt = {**base, "effect_state": state, "proposed_effect_id": proposal["effect_id"],
                           "owning_phase": OWNERS[proposal["to_status"]], "proposed_from_status": proposal["from_status"],
                           "proposed_to_status": proposal["to_status"], "reason_code": "write-effect-not-established",
                           "roadmap_before_sha256": byte_digest(observed_before)}
                if after is not None:
                    receipt["roadmap_after_sha256" if state == "not-applied" else "observed_roadmap_sha256"] = byte_digest(after)
            result = persist_receipt(project, receipt, proposal["snapshot"]["run_id"])
            if result["effect_state"] == "applied":
                try:
                    for source, expected in proposal["snapshot"]["source_map"].items():
                        if source != proposal["recovery"]["roadmap_path"] and byte_digest(read_bytes(project, source)) != expected:
                            raise ContractError("post-effect-source-changed")
                except (OSError, ContractError):
                    raise PostEffectError(result) from None
            return result
    finally:
        # The fdopen context closes its descriptor, including after errors.
        pass

def validate_specification_ready(project: Path, path: str, yaml: Any) -> dict:
    """Validate acyclic, current independent pre-brief authoring evidence."""
    packet = exact(read_json(project, path), {"schema_version", "feature_directory", "scope_sha256",
        "assessments", "required_check_ids", "satisfied_check_ids", "artifact_digests", "unresolved_ids"}, "authoring-ready")
    feature = relative(packet["feature_directory"])
    pointer = read_json(project, ".specify/feature.json")
    if packet["schema_version"] != VERSION or pointer.get("feature_directory") != feature:
        raise ContractError("authoring-target-mismatch")
    prefix = payload_prefix(project)
    manifest = loader._load_yaml(read_bytes(project, prefix + "extension.yml").decode(), "owner manifest", yaml)
    version = manifest.get("extension", {}).get("version", "")
    if not isinstance(version, str) or not re.fullmatch(r"\d+\.\d+\.\d+", version) or tuple(map(int, version.split("."))) < (0, 3, 0):
        raise ContractError("lifecycle-owner-contract-unavailable")
    spec_path = feature + "/spec.md"
    quality_path = feature + "/checklists/requirements.md"
    scope = byte_digest(read_bytes(project, spec_path))
    if packet["scope_sha256"] != scope:
        raise ContractError("authoring-scope-stale")
    checks = {"authoring-quality", "clarification", "linkage", "independent-review"}
    if (set(strings(packet["required_check_ids"], "authoring-checks", nonempty=True)) != checks
            or set(strings(packet["satisfied_check_ids"], "authoring-checks", nonempty=True)) != checks
            or strings(packet["unresolved_ids"], "authoring-unresolved")):
        raise ContractError("authoring-proof-incomplete")
    artifacts = validate_sources(project, packet["artifact_digests"])
    if not {spec_path, quality_path}.issubset(artifacts):
        raise ContractError("authoring-input-coverage-missing")
    quality = read_bytes(project, quality_path).decode("utf-8")
    markers = re.findall(r"^\s*- \[([ xX])\]", quality, re.M)
    if not markers or " " in markers:
        raise ContractError("authoring-quality-incomplete")
    snapshot = {"feature_directory": feature, "scope_sha256": scope}
    covered = set()
    for ref in evidence(project, packet["assessments"]):
        if ref["kind"] != "independent-authoring-review":
            raise ContractError("authoring-review-kind-invalid")
        record = validate_assessment(project, ref, snapshot, {"FlowKit-Reviewer"})
        if not {spec_path, quality_path}.issubset(record["artifact_digests"]):
            raise ContractError("authoring-review-input-coverage-missing")
        covered.update(record["satisfied_check_ids"])
    if not checks.issubset(covered):
        raise ContractError("authoring-independent-coverage-incomplete")
    return {"specification_ready": True, "feature_directory": feature, "scope_sha256": scope,
            "artifact_digests": artifacts, "assessment_references": packet["assessments"]}

def main() -> int:
    try:
        yaml = loader.establish_runtime(Path(__file__))
        parser = argparse.ArgumentParser(description=__doc__)
        parser.add_argument("operation", choices=("evaluate", "apply"))
        parser.add_argument("--project", required=True, type=Path)
        args = parser.parse_args()
        project = args.project.resolve(strict=True)
        value = strict_json(sys.stdin.read())
        result = evaluate(project, value, yaml) if args.operation == "evaluate" else apply(project, value, yaml)
        print(json.dumps(result, sort_keys=True, separators=(",", ":")))
        return 0 if result.get("state") in {"ready", "no-op"} or (result.get("effect_state") == "applied" and result["record_state"] != "failed") else 1
    except PostEffectError as error:
        print(json.dumps(error.receipt, sort_keys=True, separators=(",", ":")))
        print("Error: effect-applied-source-evidence-changed", file=sys.stderr)
        return 1
    except Exception as error:
        message = str(error) if isinstance(error, ContractError) else "lifecycle request could not be safely completed"
        print("Error: " + json.dumps(message)[1:-1], file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
